import {PolicyService} from '../services/policy.service';
import {Component, OnInit} from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  policyForm: any = {};
  validMessage: string = '';
  isRegisterSuccess: boolean;
  public userId;
  constructor(private policyService: PolicyService, private router: Router) {

  }

  ngOnInit() {

  }

  register() {
    this.policyService.registerUser(this.policyForm).subscribe(
      (data) => {
        this.userId = data;
        this.isRegisterSuccess = true;
        this.policyForm.reset();
      },
      (error) => {
        console.log('Thats the error');
      });
  }
}