import { Component, OnInit } from '@angular/core';
import { PolicyService } from '../services/policy.service';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-updatepolicy',
  templateUrl: './updatepolicy.component.html',
  styleUrls: ['./updatepolicy.component.css']
})
export class UpdatepolicyComponent implements OnInit {
  policyDetails: any = {}
  policyId: any = {};

  constructor(private policyService: PolicyService, private router: Router, private data: DataService, private route: ActivatedRoute) {
    this.policyId = this.route.snapshot.params;
  }

  ngOnInit() {
    this.policyService.getSpecificPolicy(this.policyId.id).subscribe(
      (data) => {
        this.policyDetails = data
      },
      (error) => {
        console.log('Thats the error');
      });
  }

  updatePolicyDetails(){
    this.policyService.updateSpecificPolicy(this.policyDetails).subscribe(
      (data) => {
      
      },
      (error) => {
        console.log('Thats the error');
      });
  }
}
