import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {DataService} from './data.service';
import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {RegisterComponent} from './register/register.component';
import {PolicyService} from './services/policy.service';
import {PolicydetailsComponent} from './policydetails/policydetails.component';
import { UpdatepolicyComponent } from './updatepolicy/updatepolicy.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'policydetails',
    component: PolicydetailsComponent
  },
  {
    path: 'editpolicy/:id',
    component: UpdatepolicyComponent
  }
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    PolicydetailsComponent,
    UpdatepolicyComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule
  ],
  providers: [PolicyService, DataService],
  bootstrap: [AppComponent]
})
export class AppModule {}
