import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';


const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'text/plain'})
};

@Injectable()
export class PolicyService {

  constructor(private http: HttpClient) {}

  registerUser(userDetails) {
    let body = userDetails;
    console.log('inside register method' + body);
    return this.http.post('/policyApp/register', body);
  }

  checkAccess(loginDetails) {
    console.log('Inside checkaccess method');
    return this.http.post('/policyApp/login', loginDetails);
  }

  getAllPolicies() {
    return this.http.get('/policyApp/policydetails');
  }

  getUserPolicies(userName) {
    return this.http.post('/policyApp/userpolicydetails', userName);
  }

  getSpecificPolicy(policyId){
    return this.http.post('/policyApp/policydetails', policyId);
  }

  updateSpecificPolicy(policyDetails){
    return this.http.post('/policyApp/updatepolicydetails', policyDetails)
  }
}
