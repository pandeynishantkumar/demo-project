import {DataService} from '../data.service';
import {PolicyService} from '../services/policy.service';
import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-policydetails',
  templateUrl: './policydetails.component.html',
  styleUrls: ['./policydetails.component.css']
})
export class PolicydetailsComponent implements OnInit {
  policyDetails: any = {};
  userPolicyDetails: any = {};
  userDetails: any = {};

  constructor(private policyService: PolicyService, private router: Router, private data: DataService) {
    this.userDetails = this.data.userDetail;
  }

  ngOnInit() {
    this.policyService.getAllPolicies().subscribe(
      (data) => {
        console.log(data);
        this.policyDetails = data;
        console.log('List of all policies from backend: ' + this.policyDetails);
      },
      (error) => {
        console.log('Thats the error');
      });

    this.policyService.getUserPolicies(this.userDetails.userName).subscribe(
      (data) => {
        console.log(data);
        this.userPolicyDetails = data;
        console.log('List of all user policies from backend: ' + this.policyDetails);
      },
      (error) => {
        console.log('Thats the error');
      });
  }

  addPolicies() {

  }
}