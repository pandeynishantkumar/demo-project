package com.cts.PolicyManagementSystem.controller;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.cts.PolicyManagementSystem.model.PolicyDetails;
import com.cts.PolicyManagementSystem.model.UserDetails;
import com.cts.PolicyManagementSystem.model.UserPolicyDetails;
import com.cts.PolicyManagementSystem.service.PolicyService;

@RestController
@RequestMapping("policyApp")
public class PolicyManagementAppController {

	@Autowired
	private PolicyService policyService;


	@RequestMapping("/keepAlive")
	public boolean getStatus() {
		return true;
	}

	@RequestMapping("/users")
	public List<UserDetails> getUserDetails() {
		return policyService.getAllUsers();
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public UserDetails getUserStatus(@RequestBody UserDetails userNamePswdRequest) throws Exception {
		boolean userStatus = false;
		try {
			UserDetails usernamePswdDb = policyService.getUser(userNamePswdRequest.getUserName());
			return usernamePswdDb;
		} catch (Exception e) {
			throw new Exception("User Not yet registered");
		}

	}

	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Set<String> registerUser(@RequestBody UserDetails userDetailsRequestObj) throws Exception {

		String[] dateSplitted = userDetailsRequestObj.getDateOfBirth().split("-");
		String userId = userDetailsRequestObj.getFirstName() + dateSplitted[2] + dateSplitted[1];

		if (!policyService.userExists(userId)) {
			userDetailsRequestObj.setUserName(userId);
			policyService.saveUser(userDetailsRequestObj);
		} else {
			throw new Exception("User already exists.");
		}

		return Collections.singleton(userId);
	}

	@RequestMapping(value = "/policydetails", method = RequestMethod.GET, produces = "application/json")
	public List<PolicyDetails> getPolicyDetails() {
		return policyService.getAllPolicies();
	}

	@RequestMapping(value = "/userpolicydetails", method = RequestMethod.POST, produces = "application/json")
	public List<UserPolicyDetails> getUserPolicyDetails(@RequestBody String userId) {
		return policyService.getUserSpecificPolicies(userId);
	}

	@RequestMapping(value = "/updatepolicydetails", method = RequestMethod.POST)
	public PolicyDetails updatePolicyDetails(@RequestBody PolicyDetails policyDetails) {
		return policyService.updatePolicyDetails(policyDetails);
	}

	@RequestMapping(value = "/policydetails", method = RequestMethod.POST, produces = "application/json", consumes = "text/plain")
	public PolicyDetails getPolicyDetails(@RequestBody String policyId) {
		return policyService.getPolicyDetails(policyId);
	}

}
