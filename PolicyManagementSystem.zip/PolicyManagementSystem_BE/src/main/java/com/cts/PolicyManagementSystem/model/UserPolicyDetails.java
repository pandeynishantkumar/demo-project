package com.cts.PolicyManagementSystem.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="userpolicydetails")
public class UserPolicyDetails {
	
	@Column(name="amountpaid")
	@JsonProperty
	private double amountPaid;
	
	@Column(name="policyenddate")
	@JsonProperty
	private String policyEndDate;
	
	@Id
	@JsonProperty
	@Column(name="userpolicydetailsid")
	private Integer userPolicyDetailsId;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="policy_id", referencedColumnName="policyId", nullable=false)
	private PolicyDetails policyDetails;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="username", referencedColumnName="userName", nullable=false)
	private UserDetails userDetails;
	
	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	public PolicyDetails getPolicyDetails() {
		return policyDetails;
	}
	public void setPolicyDetails(PolicyDetails policyDetails) {
		this.policyDetails = policyDetails;
	}
	public Integer getUserPolicyDetailsId() {
		return userPolicyDetailsId;
	}
	public void setUserPolicyDetailsId(Integer userPolicyDetailsId) {
		this.userPolicyDetailsId = userPolicyDetailsId;
	}
	public double getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
	public String getPolicyEndDate() {
		return policyEndDate;
	}
	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}
}
