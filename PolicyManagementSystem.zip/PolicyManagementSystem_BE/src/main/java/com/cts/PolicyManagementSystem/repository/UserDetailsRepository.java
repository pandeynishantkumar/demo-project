package com.cts.PolicyManagementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cts.PolicyManagementSystem.model.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, String>{

}
