package com.cts.PolicyManagementSystem.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.PolicyManagementSystem.model.PolicyDetails;
import com.cts.PolicyManagementSystem.model.UserDetails;
import com.cts.PolicyManagementSystem.model.UserPolicyDetails;
import com.cts.PolicyManagementSystem.repository.PolicyDetailsRepository;
import com.cts.PolicyManagementSystem.repository.UserDetailsRepository;
import com.cts.PolicyManagementSystem.repository.UserPolicyDetailsRepository;

@Service
public class PolicyService {
	@Autowired
	UserDetailsRepository userDetailsRepo;

	@Autowired
	PolicyDetailsRepository policyDetailsRepository;

	@Autowired
	private UserPolicyDetailsRepository userPolicyDetailsRepository;

	public List<UserDetails> getAllUsers() {
		return userDetailsRepo.findAll();
	}
	public UserDetails getUser(String userName) {
		return userDetailsRepo.getOne(userName);

	}
	public void saveUser(UserDetails userDetails) {
		userDetailsRepo.save(userDetails);
	}
	public boolean userExists(String userId) {
		return userDetailsRepo.existsById(userId);
	}
	public List<PolicyDetails> getAllPolicies() {
		return policyDetailsRepository.findAll();
	}
	public List<UserPolicyDetails> getUserSpecificPolicies(String userName) {
		return userPolicyDetailsRepository.findUserPolicyDetailsByUserName(userName);
	}
	public PolicyDetails updatePolicyDetails(PolicyDetails policyDetails) {
		return policyDetailsRepository.save(policyDetails);
	}
	public PolicyDetails getPolicyDetails(String policyId) {
		return policyDetailsRepository.getOne(Integer.valueOf(policyId));
	}
}
