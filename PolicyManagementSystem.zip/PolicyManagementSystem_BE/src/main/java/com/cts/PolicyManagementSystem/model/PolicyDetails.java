package com.cts.PolicyManagementSystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

@Entity
@Table(name = "policydetails")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class PolicyDetails {

	@JsonProperty("policyName")
	private String policyName;
	public PolicyDetails() {};
	public PolicyDetails(String policyName, String policyDetails, Integer policyId) {
		super();
		this.policyName = policyName;
		this.policyDetails = policyDetails;
		this.policyId = policyId;
	}
	
	@JsonProperty
	private String policyDetails;
	
	@Id
	@JsonProperty
	private Integer policyId;
	
	public Integer getPolicyId() {
		return policyId;
	}
	public void setPolicyId(Integer policyId) {
		this.policyId = policyId;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getPolicyDetails() {
		return policyDetails;
	}
	public void setPolicyDetails(String policyDetails) {
		this.policyDetails = policyDetails;
	}
}
