package com.cts.PolicyManagementSystem.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;
import com.cts.PolicyManagementSystem.model.UserPolicyDetails;

public interface UserPolicyDetailsRepository extends Repository<UserPolicyDetails, Integer>{
	@Query(value = "SELECT u FROM UserPolicyDetails u WHERE u.userDetails.userName = :userName")
	List<UserPolicyDetails> findUserPolicyDetailsByUserName(@Param(value = "userName")String userName);
}
