For installing all required dependencies run the below command
#npm install
Please ignore error/warn related to phython while doing npm install, please continue to next step
For install the bootstrap run below
# npm install bootstrap
To run this  application run below command and it will start the node server on localhost:4200
#npm start

 
 