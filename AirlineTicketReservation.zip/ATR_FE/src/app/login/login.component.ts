import {DataService} from '../data.service';
import {PolicyService} from '../services/policy.service';
import {Component, OnInit} from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: any = {};
  userStatus: any;
  message: string = '';

  constructor(private policyService: PolicyService, private router: Router, private data: DataService) {}

  ngOnInit() {
  }

  login() {
    console.log('Inside login', this.loginForm);
    this.policyService.checkAccess(this.loginForm).subscribe(
      (data) => {
        console.log(data);
        this.data.setUserDetail(data);
        this.router.navigateByUrl('/bookingdetails');
   
      },
      (error) => {
        console.log('Thats the error');
      });
  }

}
