package com.cts.airlineticket.controller;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ticketmanagement.model.FlightDetails;
import com.cts.ticketmanagement.model.UserBookings;
import com.cts.ticketmanagement.model.UserDetails;
import com.cts.ticketmanagement.service.TicketBookingService;

@RestController
@RequestMapping("/ticketApp")
public class AirlineTicketReservationSystemController {

	@Autowired
	private TicketBookingService ticketBookingService;


	@RequestMapping("/keepAlive")
	public boolean getStatus() {
		return true;
	}

	@RequestMapping("/users")
	public List<UserDetails> getUserDetails() {
		return ticketBookingService.getAllUsers();
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public UserDetails getUserStatus(@RequestBody UserDetails userNamePswdRequest) throws Exception {
		boolean userStatus = false;
		try {
			UserDetails usernamePswdDb = ticketBookingService.getUser(userNamePswdRequest.getUserName());

			// userStatus =
			// userNamePswdRequest.getPassword().equals(usernamePswdDb.getPassword());
			return usernamePswdDb;
		} catch (Exception e) {
			throw new Exception("User Not yet registered");
		}

	}

	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Set<String> registerUser(@RequestBody UserDetails userDetailsRequestObj) throws Exception {

		String userId = userDetailsRequestObj.getUserName();

		if (!ticketBookingService.userExists(userId)) {
			userDetailsRequestObj.setUserName(userId);
			ticketBookingService.saveUser(userDetailsRequestObj);
		} else {
			throw new Exception("User already exists.");
		}

		return Collections.singleton(userId);
	}
	@RequestMapping(value="/userbooking/bookticket", method = RequestMethod.POST)
	public void bookTicket(@RequestBody List<UserBookings> userBooking){
		ticketBookingService.bookUserTicket(userBooking);
		
	}
	@RequestMapping(value = "/userbookings/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<UserBookings> getUserBookings(@PathVariable String userId){
		return ticketBookingService.getUserSpecificBookings(userId);	
	}

	@RequestMapping(value = "/userbookings/searchflight", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FlightDetails> searchFlight(@RequestBody FlightDetails searchFlightRequest){
		return ticketBookingService.getFlightDetails(searchFlightRequest);	
	}

}
