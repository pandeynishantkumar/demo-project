package com.cts.airlineticket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ticketmanagement.model.FlightDetails;
import com.cts.ticketmanagement.model.UserBookings;
import com.cts.ticketmanagement.model.UserDetails;
import com.cts.ticketmanagement.repository.FlightDetailsRepository;
import com.cts.ticketmanagement.repository.UserBookingDetailsRepository;
import com.cts.ticketmanagement.repository.UserDetailsRepository;

@Service
public class TicketBookingService {
	@Autowired
	private UserDetailsRepository userDetailsRepo;

	@Autowired
	private UserBookingDetailsRepository bookingDetailsRepository;
	
	@Autowired
	private FlightDetailsRepository flightDetailsRepository;

	public List<UserDetails> getAllUsers() {
		return userDetailsRepo.findAll();
	}

	public UserDetails getUser(String userName) {
		return userDetailsRepo.getOne(userName);
	}

	public void saveUser(UserDetails userDetails) {
		userDetailsRepo.save(userDetails);
	}

	public boolean userExists(String userId) {
		return userDetailsRepo.existsById(userId);
	}
	
	public List<UserBookings> getUserSpecificBookings(String userId){
		return bookingDetailsRepository.findUserPolicyDetailsByUserName(userId);
	}
	
	public List<FlightDetails> getFlightDetails(FlightDetails searchFlightRequest){
		return flightDetailsRepository.getFlightDetails(searchFlightRequest.getSource(), searchFlightRequest.getDestination(), searchFlightRequest.getDepartureDate(), searchFlightRequest.getDepartureTime(), searchFlightRequest.getClassType());
	}

	public void bookUserTicket(List<UserBookings> userBookingList) {
		for(UserBookings userBookingRecord: userBookingList)
		bookingDetailsRepository.addBookingsRepo(userBookingRecord.getUserName(), userBookingRecord.getFlightDetails().getFlightId());
	}
}
