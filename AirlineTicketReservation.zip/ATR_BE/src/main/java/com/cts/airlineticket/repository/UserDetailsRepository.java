package com.cts.airlineticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.ticketmanagement.model.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, String>{

}