package com.cts.airlineticket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.cts.ticketmanagement.model.FlightDetails;

public interface FlightDetailsRepository extends JpaRepository<FlightDetails, String>{
	
	@Query(value = "SELECT f FROM FlightDetails f  WHERE f.source =:source and f.destination =:destination and f.departureDate=:departureDate and f.departureTime=:departureTime and classType=:classType")
	List<FlightDetails> getFlightDetails(@Param(value = "source")String source, @Param(value="destination")String destination,@Param(value="departureDate")String departureDate, @Param(value="departureTime")String departureTime, @Param(value="classType")String classType);

}
