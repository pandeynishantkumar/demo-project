package com.cts.airlineticket.repository;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.ticketmanagement.model.UserBookings;

public interface UserBookingDetailsRepository extends JpaRepository<UserBookings,String> {
	
	@Query(value = "SELECT u  FROM UserBookings u  WHERE u.userName = :userName and u.isActive='Yes'")
	List<UserBookings> findUserPolicyDetailsByUserName(@Param(value = "userName")String userName);
	
	@Modifying
	@Query(value = "insert into user_bookings(user_name, flight_id) values(:userName, :flightId)", nativeQuery = true)
	@Transactional
	public void addBookingsRepo(@Param("userName") String userName, @Param("flightId") String flightId);

}
