Step1: Add User previlage set username and password for mySql as 'root' and 'root'

Step2: Create schema with name test

Step3: Run mvn clean install in Java

Step4: Run your Java application

Step5: Run the below queries in mySql

INSERT INTO `test`.`user_details` (`login_id`, `password`) VALUES ('admin', 'admin');


ALTER TABLE `test`.`license_details` 
CHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT ;


Step6: Do npm install in Angular applicaiton

Step7: Do npm start to start Agent management system

Step 8: open http://localhost:4200 in Chrome >> login username and password 'admin' and 'admin'