This project was created from spring boot initializer.
Using Web , JPA 
for DB , MySQL was used and the required jar(mysql connector)  file was added to class path manually.

<dependency>
			<groupId>mysql</groupId>
			<artifactId>mysql-java-connector</artifactId>
			<version>5.1.6</version>
		</dependency>
		
run the command  mvn clean install  from command prompt..
#For the DB scripts please executescripts inside sqlstatement/ folder.
For the DB username was given as root and password is root.
Can be seen in application.properties file. 
Run the application TicketManagementSystemApplication.java and it will listen on port 9000
The application was developed for login user, create user and display user bookings alone .No search functionality for flight was implemented.
please use this user 'pawan@gmail.com' and password is 'power123' for display user bookings