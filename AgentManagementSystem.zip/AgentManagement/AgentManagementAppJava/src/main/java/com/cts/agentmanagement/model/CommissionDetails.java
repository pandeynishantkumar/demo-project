package com.cts.agentmanagement.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
public class CommissionDetails {
	@Id
	private int id;
	@JsonProperty
	private String agentId;
	@JsonProperty
	private String agentName;
	@JsonProperty
	private String totalPolicyAmount;
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getTotalPolicyAmount() {
		return totalPolicyAmount;
	}
	public void setTotalPolicyAmount(String totalPolicyAmount) {
		this.totalPolicyAmount = totalPolicyAmount;
	}
	public String getPolicies() {
		return policies;
	}
	public void setPolicies(String policies) {
		this.policies = policies;
	}
	public String getTotalCommissionAmount() {
		return totalCommissionAmount;
	}
	public void setTotalCommissionAmount(String totalCommissionAmount) {
		this.totalCommissionAmount = totalCommissionAmount;
	}
	@JsonProperty
	private String policies;
	@JsonProperty
	private String totalCommissionAmount;

}
