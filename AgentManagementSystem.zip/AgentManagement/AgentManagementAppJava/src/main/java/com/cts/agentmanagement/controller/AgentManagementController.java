package com.cts.agentmanagement.controller;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.agentmanagement.model.AgentDetails;
import com.cts.agentmanagement.model.CommissionDetails;
import com.cts.agentmanagement.model.LicenseDetails;
import com.cts.agentmanagement.model.UserBookings;
import com.cts.agentmanagement.model.UserDetails;
import com.cts.agentmanagement.service.AgentManagementSystemService;

@RestController
@RequestMapping("/agentapp")
public class AgentManagementController {

	@Autowired
	private AgentManagementSystemService agentManagmentService;


	@RequestMapping("/keepAlive")
	public boolean getStatus() {
		return true;
	}

	@RequestMapping("/users")
	public List<UserDetails> getUserDetails() {
		return agentManagmentService.getAllUsers();
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean getUserStatus(@RequestBody UserDetails userNamePswdRequest) throws Exception {
		boolean userStatus = false;
		try {
			UserDetails usernamePswdDb = agentManagmentService.getUser(userNamePswdRequest.getLoginId());

			userStatus =
			userNamePswdRequest.getPassword().equals(usernamePswdDb.getPassword());
			return userStatus;
		} catch (Exception e) {
			throw new Exception("User Not yet registered");
		}

	}
	
	@RequestMapping(value="/getallagents", method = RequestMethod.GET)
	public List<AgentDetails> getAllAgents(){
		return agentManagmentService.getAllAgents();
		
	}

	@RequestMapping(value="/registeragent", method = RequestMethod.POST)
	public void registerAgent(@RequestBody AgentDetails agentDetails){
		agentManagmentService.registerAgent(agentDetails);
		
	}
	
	@RequestMapping(value="/addlicense", method = RequestMethod.POST)
	public void addLicense(@RequestBody LicenseDetails licenseDetails){
		agentManagmentService.addLicense(licenseDetails);
		
	}
	
	@RequestMapping(value="/addcommission", method = RequestMethod.POST)
	public void addLicense(@RequestBody CommissionDetails commissionDetails){
		agentManagmentService.addCommission(commissionDetails);
		
	}


}
