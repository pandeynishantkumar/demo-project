package com.cts.agentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AgentManagementSystemApplication {
//	@Autowired
//	private static AgentManagementSystemService agentManagementSystemService;
	

	public static void main(String[] args) {
		SpringApplication.run(AgentManagementSystemApplication.class, args);

	}
}
