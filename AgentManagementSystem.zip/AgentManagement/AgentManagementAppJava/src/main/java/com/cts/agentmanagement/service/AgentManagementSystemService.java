package com.cts.agentmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.agentmanagement.model.AgentDetails;
import com.cts.agentmanagement.model.CommissionDetails;
import com.cts.agentmanagement.model.LicenseDetails;
import com.cts.agentmanagement.model.UserDetails;
import com.cts.agentmanagement.repository.CommisionDetailsRepository;
import com.cts.agentmanagement.repository.FlightDetailsRepository;
import com.cts.agentmanagement.repository.LicenseRepository;
import com.cts.agentmanagement.repository.RegisterAgentRepository;
import com.cts.agentmanagement.repository.UserDetailsRepository;

@Service
public class AgentManagementSystemService {
	
	int agentId = 1000;
	
	@Autowired
	private UserDetailsRepository userDetailsRepo;

	@Autowired
	private RegisterAgentRepository agentRepo;
	
	@Autowired
	private LicenseRepository licenseRepository;
	
	@Autowired
	private CommisionDetailsRepository commisionDetailsRepository;

	public List<UserDetails> getAllUsers() {
		return userDetailsRepo.findAll();
	}

	public UserDetails getUser(String userId) {
		return userDetailsRepo.getOne(userId);

	}

	public void saveUser(UserDetails userDetails) {
		userDetailsRepo.save(userDetails);
	}

	public boolean userExists(String userId) {
		return userDetailsRepo.existsById(userId);
	}
	

	
	public List<AgentDetails> getAllAgents(){
		return agentRepo.findAll();
	}
	public void registerAgent(AgentDetails agentDetails) {
		// TODO Auto-generated method stub
		agentDetails.setAgentId(agentDetails.getJobType()+ agentId++);
		agentRepo.save(agentDetails);
		
	}
	
	public void addLicense(LicenseDetails licenseDetails) {
		licenseRepository.save(licenseDetails);
	}
	
	public void addCommission(CommissionDetails commissionDetail) {
		commisionDetailsRepository.save(commissionDetail);
	}

}
