package com.cts.agentmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.agentmanagement.model.AgentDetails;

public interface FlightDetailsRepository extends JpaRepository<AgentDetails, String>{
	

}
