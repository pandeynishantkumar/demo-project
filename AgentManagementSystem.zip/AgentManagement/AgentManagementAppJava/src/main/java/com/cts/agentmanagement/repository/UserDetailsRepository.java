package com.cts.agentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.agentmanagement.model.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, String>{

}
