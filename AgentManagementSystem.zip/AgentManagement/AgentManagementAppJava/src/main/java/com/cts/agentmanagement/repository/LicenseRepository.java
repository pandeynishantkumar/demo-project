package com.cts.agentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.agentmanagement.model.LicenseDetails;

public interface LicenseRepository extends JpaRepository<LicenseDetails, Integer>{

}
