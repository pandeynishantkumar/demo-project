package com.cts.agentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.agentmanagement.model.CommissionDetails;

public interface CommisionDetailsRepository extends JpaRepository<CommissionDetails, Integer>{

}
