//package com.cts.PolicyManagementSystem.controller;
//
//import static org.hamcrest.CoreMatchers.any;
//import static org.junit.Assert.*;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import com.cts.PolicyManagementSystem.model.PolicyDetails;
//import com.cts.PolicyManagementSystem.repository.PolicyDetailsRepository;
//import com.cts.PolicyManagementSystem.service.PolicyService;
//
//@RunWith(MockitoJUnitRunner.class)
//public class PolicyManagementAppControllerTest {
//
//	@InjectMocks
//	private PolicyManagementAppController policyManagementAppController;
//	
//	@Mock
//	private PolicyService policyService;
//	
//	@Mock
//	private PolicyDetailsRepository policyDetailsRepo;
//	
//	@Test
//	public void testGetStatus() {
//		boolean status = policyManagementAppController.getStatus();
//		assertTrue(status);
//	}
//
//	@Test
//	public void testRegisterUser() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testGetPolicyDetails() throws Exception {
//		//when(policyDetailsRepo.findAll()).thenReturn(mockPolicyDetails());
//		
//		when(policyService.getAllPolicies()).thenReturn(mockPolicyDetails());
//		List<PolicyDetails> policyDetailsList = policyManagementAppController.getPolicyDetails();
//		assertNotNull(policyDetailsList);
//		assertEquals(policyDetailsList.get(0).getPolicyName(), "policy 1");
//	}
//
//	private List<PolicyDetails> mockPolicyDetails() {
//		// TODO Auto-generated method stub
//		List<PolicyDetails> policyDetails = new ArrayList<>();
//		
//		policyDetails.add(new PolicyDetails("policy 1","policy details 1", 1));
//		policyDetails.add(new PolicyDetails("policy 2","policy details 2", 2));
//		policyDetails.add(new PolicyDetails("policy 3","policy details 3", 3));
//		
//		return policyDetails;
//	}
//
//	@Test
//	public void testGetUserPolicyDetails() {
//		when(policyService.getPolicyDetails("2")).thenReturn(mockPolicyDetails().get(1));
//		PolicyDetails policyDetails = policyManagementAppController.getPolicyDetails("2");
//		assertEquals(policyDetails.getPolicyName(),"policy 2");
//	
//	}
//
//	@Test
//	public void testUpdatePolicyDetails() {
//		when(policyService.updatePolicyDetails((PolicyDetails) any(PolicyDetails.class))).thenReturn(mockPolicyDetails().get(1));
//		PolicyDetails policyDetails = policyManagementAppController.updatePolicyDetails(new PolicyDetails("updated policy 1","updated policy details", 5));
//		assertNotNull(policyDetails);
//	
//	}
//
//	
//
//}
