For installing all required dependencies run the below command
#npm install
For install the bootstrap run below
# npm instal bootstrap
To run this  application run below command and it will start the node server on localhost:4200
#npm start

 
 