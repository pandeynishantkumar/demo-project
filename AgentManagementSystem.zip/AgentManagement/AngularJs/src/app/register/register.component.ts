import {PolicyService} from '../services/policy.service';
import {Component, OnInit, ViewChild} from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  agentForm: any = {};
  validMessage: string = '';
  isRegisterSuccess: boolean;
  public userId;
  agentsList: any = {};
  @ViewChild('agentForm1') f;

  constructor(private policyService: PolicyService, private router: Router) {

  }


  ngOnInit() {}

  validateDate(dateField){
    const formDob = this.f.form.controls.dob;
    console.log(formDob)
    const dateValue = formDob.value.split('-').reverse();
    console.log(dateValue);
    const date = new Date();
    date.setDate(parseInt(dateValue[0]));
    date.setMonth(parseInt(dateValue[1]) -1);
    date.setFullYear(parseInt(dateValue[2]));
    const dateDiff = Date.now() - date.getTime();
    const newDate = new Date(dateDiff);
    const age = newDate.getUTCFullYear() - 1970;
    formDob.setErrors(null);
    if(Math.abs(age) < 18){
      formDob.setErrors({minor: true});
    }
  }

  register() {
   
    this.policyService.registerUser(this.agentForm).subscribe(
      (data) => {
        console.log(data);
        this.userId = data;
        console.log('User Id returned from backend is' + this.userId);
        this.isRegisterSuccess = true;
        this.policyService.userData = this.agentForm;
        this.router.navigate(['agentdetails'],{queryParams : {userid : this.agentForm.userid}});
        

      },
      (error) => {
        console.log('Thats the error');
      });



  }
}
