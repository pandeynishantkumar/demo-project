import {DataService} from '../data.service';
import {PolicyService} from '../services/policy.service';
import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'agentdetails',
  templateUrl: './agentdetails.component.html',
  styleUrls: ['./agentdetails.component.css']
})
export class AgentdetailsComponent implements OnInit {
  userSpecificBookings: any = {};
  userDetails: any = {};
  searchFlight: any = {};
  defaultSelectValue: string = "-- select --";
  searchedFlightDetailsList: any = {};
  agentsList: any = {};



  constructor(private policyService: PolicyService, private router: Router, private data: DataService) {
    this.userDetails = this.policyService.userData;
    console.log(this.userDetails);
  }

  ngOnInit() {
    this.policyService.getAllAgents().subscribe(
      (data) => {this.agentsList = data},
      error => {}
    );
  }

  bookSelectedFlight() {
    const bookedFlightsArray = this.searchedFlightDetailsList.filter(item => item.isSelected);
      /* return {
        userName: this.data.userDetail.userName,
        flightDetails: item,
        numberOfPassengers: this.searchFlight.passengers,
       
      }
    ); */
    let flightBookingArr:any =[];
     bookedFlightsArray.map(item => {
        flightBookingArr.push({
          userName: this.data.userDetail.userName,
          flightDetails: item,
          numberOfPassengers: this.searchFlight.passengers     
        })
    })


    console.log(flightBookingArr);

    /* console.log(this.bookedFlights);
    
    this.policyService.bookUserTickets(bookedFlightsArray).subscribe();
    this.bookedFlights = {};
    this.policyService.getUserBookings(this.userDetails.userName).subscribe(
      (data) => {this.bookingHistoryList = data},
      error => {}
    ); */
  }

  searchFlights(){
    console.log(this.searchFlight);
    this.policyService.getSearchFlight(this.searchFlight).subscribe(
      (data) => {this.searchedFlightDetailsList=data},(error) => {}
    );
  }

}
