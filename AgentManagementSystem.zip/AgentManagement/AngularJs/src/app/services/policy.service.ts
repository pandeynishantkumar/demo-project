import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';


const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'text/plain'})
};

@Injectable()
export class PolicyService {

  userData: any = {};
  
  constructor(private http: HttpClient) {}
  
  registerUser(userDetails) {
    let body = userDetails;
    console.log('inside register method' + body);
    return this.http.post('/agentapp/registeragent', body);
  }

  checkAccess(loginDetails) {
    console.log('Inside checkaccess method');
    return this.http.post('/agentapp/login', loginDetails);
  }

  getUserBookings(userName) {
    return this.http.get('/ticketApp/userbookings/' + userName);
  }

  getSearchFlight(searchInput){
      return this.http.post('/ticketApp/userbookings/searchflight', searchInput);
  }

  bookUserTickets(bookedTickets){
      return this.http.post('/ticketApp/userbooking/bookticket', bookedTickets);
  }

  getAllAgents(){
    return this.http.get('/agentapp/getallagents');
  }

  addLicense(licenseDetails){
    return this.http.post('/agentapp/addlicense', licenseDetails);
  }

}
